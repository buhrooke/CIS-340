#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>


#include "showsuper.h"
#include "getsuper.h"


void showzone(int fd, int zone) {
  struct minix_super_block *superBlock = getSuperBlock(fd);
  int zoneNum = zone;
  printf("zone value: %d\n",zoneNum);





}
