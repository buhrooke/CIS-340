void help(){
    printf("##########\nAvailable commands:\n\nminimount \nminiumount \nshowsuper \ntraverse \nshowzone \nshowfile \nquit\n##########\n");
}
